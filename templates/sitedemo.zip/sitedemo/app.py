from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import UserMixin, login_user, logout_user, current_user, LoginManager
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from datetime import datetime, timedelta
import secrets
import os
from dotenv import load_dotenv

import cloudinary
import cloudinary.uploader
import cloudinary.api

load_dotenv()

app=Flask(__name__,template_folder='templates')
cloudinary.config( 
  cloud_name = "doxj9pjvr", 
  api_key = "629727456658243", 
  api_secret = "xWUK83YdSiZQsmR8GgPxWN8v_2w" 
)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.db')
# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:S%40hil276@localhost/flasksite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
app.config['SECRET_KEY'] = 'secret-key-goes-here'
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=14)
app.config['REMEMBER_COOKIE_HTTPONLY'] = True
app.config['REMEMBER_COOKIE_SECURE'] = True
secret_key = secrets.token_hex(16)
app.secret_key = secret_key

login_manager = LoginManager()
login_manager.init_app(app)

# Association Table
cart_items = db.Table(
    'cart_items',
    db.Column('cart_id', db.Integer, db.ForeignKey('cart.id'), primary_key=True),
    db.Column('cover_id', db.Integer, db.ForeignKey('covers.id'), primary_key=True),
    db.Column('cover_quantity', db.Integer, nullable=False, default=1)
)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(250), nullable=False)
    email = db.Column(db.String(250), nullable=False)
    password = db.Column(db.String(250), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    comments = db.relationship('Comment', backref='user')
    orders = db.relationship('Order', backref='user')
    cart = db.relationship('Cart', backref='user', uselist=False)



class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    covers = db.relationship('Covers', backref='order')
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    date = db.Column(db.String(250), nullable=False)

class Covers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(250), nullable=False)
    model = db.Column(db.String(250), nullable=False)
    price = db.Column(db.String(250), nullable=False)
    image = db.Column(db.String(250), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    carts = db.relationship('Cart', secondary=cart_items, backref='covers', overlaps="carts,covers")


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(250), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    items = db.relationship('Covers', secondary=cart_items, backref='cart', overlaps="carts,covers")
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def admin_only(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return abort(403)
        return f(*args, **kwargs)
    return decorated_function

def get_total_quantity():
    if current_user.is_authenticated:
        # Join necessary tables to get cart items for the current user
        query = db.session.query(func.coalesce(func.sum(cart_items.columns.cover_quantity), 0)). \
            join(Cart, Cart.id == cart_items.columns.cart_id). \
            join(User, User.id == Cart.user_id). \
            filter(User.id == current_user.id)

        quantity = query.scalar()
    else:
        quantity = 0
    return quantity

@app.route("/", methods=['POST', 'GET'])
def home():
    
    page = request.args.get('page', 1, type=int)
    per_page = 12
    covers = Covers.query.paginate(page=page, per_page=per_page, error_out=False)
    results = db.session.execute(db.select(User).order_by(User.name))
    users = results.scalars().all()
    quantity = get_total_quantity()
    return render_template("home.html",quantity=quantity, covers=covers, users=users)

@app.route("/reviews",methods=['POST', 'GET'])
def reviews():
    if request.method == "POST":
        new_comment = Comment(
            user_id=current_user.id,
            text=request.form.get('userComment')
        )
        db.session.add(new_comment)
        db.session.commit()
    results = db.session.execute(db.select(User).order_by(User.name))
    users = results.scalars().all()
    quantity = get_total_quantity()
    return render_template("comments.html",quantity=quantity,users=users)



@app.route('/add_cover', methods=['POST', 'GET'])
@admin_only
def add_cover():
    if request.method == "POST":
        if 'image' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['image']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file:
            upload_result = cloudinary.uploader.upload(
                file,
                folder="covers"
            )
            image_url = upload_result.get('url')
        new_cover = Covers(
            model=request.form.get('phoneName'),
            price=request.form.get('price'),
            image=image_url,
            quantity=request.form.get('quantity'),
            title=request.form.get('title')
        )

        db.session.add(new_cover)
        db.session.commit()
        return (redirect(url_for('home')))
    return render_template("covers_add_form.html")

@app.route('/cover_details/<cover_id>/update', methods=['GET', 'POST'])
@admin_only
def update_cover(cover_id):
    cover = Covers.query.get_or_404(cover_id)
    # Check if the current user is the owner of the cover
    if cover.user_id != current_user.id:
        flash('You do not have permission to update this cover.', 'danger')
        return redirect(url_for('home'))

    if request.method == 'POST':
        if 'image' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['image']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file:
            upload_result = cloudinary.uploader.upload(
                file,
                folder="covers"
            )
            image_url = upload_result.get('url')
        cover.model = request.form.get('phoneName')
        cover.price = request.form.get('price')
        cover.image = image_url
        cover.quantity = request.form.get('quantity')
        cover.title = request.form.get('title')
        db.session.commit()
        flash('Cover updated successfully!', 'success')
        return redirect(url_for('home'))
    else:
        return render_template('update_cover_form.html', cover=cover)

@app.route('/cover_details/<cover_id>/delete', methods=['DELETE'])
def delete_cover_perm(cover_id):
    # Check if the user is authenticated and is an admin
    if current_user.is_authenticated and current_user.is_admin:
        # Query the cover by ID
        cover = Covers.query.get(cover_id)
        if cover:
            # Delete the cover
            db.session.delete(cover)
            db.session.commit()
            return jsonify({'message': 'Cover deleted successfully'}), 200
        else:
            return jsonify({'error': 'Cover not found'}), 404
    else:
        return jsonify({'error': 'Unauthorized'}), 401
    
    
@app.route('/cover_details/<cover_id>', methods=['POST', 'GET'])
def cover_detais(cover_id):
    if request.method == "POST":
        new_comment = Comment(
            user_id=current_user.id,
            text=request.form.get('userComment')
        )
        db.session.add(new_comment)
        db.session.commit()
    results = db.session.execute(db.select(User).order_by(User.name))
    users = results.scalars().all()
    cover = db.get_or_404(Covers, cover_id)
    cancelled_price=int(cover.price)*10
    return render_template("cover_details.html", cover=cover, users=users, cancelled_price=cancelled_price)


# Assuming you have a route to delete covers



@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        results = db.session.execute(db.select(User).where(User.email == request.form.get('email')))
        user = results.scalar()
        if user:
            password = request.form.get('password')
            if (check_password_hash(user.password, password)):
                login_user(user)
                return redirect(url_for('home'))
            else:
                flash("Incorrect password!")
        else:
            flash('No  account found with that email address. Please register or check your entry.')
    return render_template("login-form.html")


@app.route('/signup', methods=['POST', 'GET'])
def signup():
    if request.method == 'POST':
        results = db.session.execute(db.select(User).where(User.email == request.form.get('email')))
        user = results.scalar()
        if not user:
            if request.form.get('customer'):
                seller=False
            else:
                seller=True
            new_user = User(
                name=request.form.get('username'),
                email=request.form.get('email'),
                password=generate_password_hash(request.form.get('password')),
                is_admin=seller
            )
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user)
            return redirect(url_for('home'))
        else:
            flash(f"An account is already registered to this email.")
    return render_template('signup-form.html')


@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))


@app.route("/add-to-cart/<int:cover_id>")
def add_to_cart(cover_id):
    if not current_user.is_authenticated:
        return render_template('not_log_in.html', message="You need to be logged in to add items to your cart")

    user = current_user
    cover = db.get_or_404(Covers, cover_id)

    if user.cart is None:
        user.cart = Cart()
        db.session.commit()

    user_cart = user.cart
    cart_item = db.session.query(cart_items).filter_by(cart_id=user_cart.id, cover_id=cover.id).first()

    if cart_item is None:
        # Create a new entry in the association table
        db.session.execute(cart_items.insert().values(cart_id=user_cart.id, cover_id=cover.id, cover_quantity=1))
    else:
        # Update the cover_quantity column in the cart_items table
        db.session.execute(
            cart_items.update().where(cart_items.c.cart_id == user_cart.id, cart_items.c.cover_id == cover.id).values(
                cover_quantity=cart_item.cover_quantity + 1))

    # Check if the cover is not already in user_cart.items
    if cover not in user_cart.items:
        # Directly append the cover to user_cart.items
        user_cart.items.append(cover)

    db.session.commit()

    return redirect(url_for('home'))


@app.route("/view_cart")
def view_cart():
    if not current_user.is_authenticated:
        return render_template('not_log_in.html', message="You need to be logged in to access your cart")

    user = current_user
    user_cart = user.cart

    if user_cart is None:
        user_cart = Cart(user_id=user.id)
        db.session.add(user_cart)
        db.session.commit()

    user_cart_items = user_cart.items
    total = 0
    items = []

    for item in user_cart_items:
        # Use db.session.query(cart_items) to get the cover_quantity
        cart_item = db.session.query(cart_items).filter_by(cart_id=user_cart.id, cover_id=item.id).first()
        cover_item = {
            'cover': item,
            'cover_quantity': cart_item.cover_quantity if cart_item else 0,  # Default to 0 if cart_item is None
            'image': item.image,
            'price': item.price,
            'title': item.title,
            'model': item.model,
            'id': item.id
        }
        items.append(cover_item)
        total += int(item.price.split('.')[0]) * cover_item['cover_quantity']

    return render_template("cart.html", items=items, total=total)


@app.route("/delete_item/<int:cover_id>")
def delete_cover(cover_id):
    user = current_user
    user_cart = user.cart
    cover_to_remove = db.get_or_404(Covers, cover_id)
    cart_item = db.session.query(cart_items).filter_by(cart_id=user_cart.id, cover_id=cover_to_remove.id).first()
    if cart_item:
        db.session.execute(cart_items.delete().where(cart_items.c.cart_id == user_cart.id,
                                                     cart_items.c.cover_id == cover_to_remove.id))
        db.session.commit()

    return redirect(url_for('view_cart'))


@app.route('/search_covers/')
def search_covers():
    s = request.args.get('query', '')
    results = Covers.query.filter(Covers.title.ilike(f"%{s}%")).all()
    return render_template('results.html', results=results, query=s)


@app.route('/about-me')
def about_me():
    return render_template("about.html")


@app.route('/account')
def account():
    if current_user.is_authenticated:
        orders = Order.query.filter_by(user_id=current_user.id).all()
        return render_template("account.html", user=current_user, items=orders)
    else:
        return render_template("not_log_in.html", message="You need to be logged in to check your account")


@app.route('/checkout', methods=['POST', 'GET'])
def checkout():
    if request.method == 'POST':
        user = current_user
        new_order = Order(
            user_id=user.id,
            date=str(datetime.today().date())
        )
        db.session.add(new_order)
        db.session.commit()

        for item in user.cart.items:
            cart_it = db.session.query(cart_items).filter_by(cart_id=user.cart.id, cover_id=item.id).first()
            if cart_it:
                item.order_id = new_order.id
                cover = db.session.get(Covers, item.id)
                cover.quantity -= cart_it.cover_quantity
                db.session.query(cart_items).filter_by(cart_id=user.cart.id, cover_id=item.id).delete()
                db.session.commit()

        user.cart.items = []
        db.session.commit()
        return render_template("order_sucess.html")

    user = current_user
    if not current_user.is_authenticated or user.cart is None:
        return render_template("not_log_in.html", message='Session Expired! Please Log In Again')

    user_cart = user.cart
    user_cart_items = user_cart.items
    total = 0
    items = []

    for item in user_cart_items:
        # Use db.session.query(cart_items) to get the cover_quantity
        cart_item = db.session.query(cart_items).filter_by(cart_id=user_cart.id, cover_id=item.id).first()
        cover_item = {
            'cover': item,
            'cover_quantity': cart_item.cover_quantity,
            'image': item.image,
            'price': item.price,
            'title': item.title,
            'model': item.model,
            'id': item.id
        }
        items.append(cover_item)
        total += int(item.price.split('.')[0]) * cover_item['cover_quantity']
    return render_template("checkout.html", items=items, total=total)


hashed_password = generate_password_hash("S@hil276")

with app.app_context():
    # your code here, e.g., database operations
    new_admin = User(
    name = 'Raksha',
    email = 'rakshabv@example.com',
    password = hashed_password,  # make sure to hash passwords
    is_admin = True
    )
    db.session.add(new_admin)
    db.session.commit()

if __name__ == "__main__":
    app.run(debug=True)